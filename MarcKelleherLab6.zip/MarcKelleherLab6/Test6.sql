/*
Marc Kelleher
CIS 276
Lab 6
2/20/18
*/

--Test condition:  All valid input values:

CustID:   1
OrderID:  6099
PartID:   1002
Qty:      1

BEFORE running program:
Highest order:
6099  101 1 15-DEC-95 
      
Inventory:      
1002	doohickey   	69	25	25
      
AFTER running program:      
New order:
6240	101	1	27-FEB-18

New inventory:
1002	doohickey   	68	25	25

--Test condition:  Invalid Customer ID

CustID:   0
OrderID:  6099
PartID:   1002
Qty:      1

Result:
anonymous block completed
Adding new order for customer 0.
This order encountered the following error: 
ORA-01403: no data found                          

--Test condition:  Invalid Order ID

CustID:   1
OrderID:  0
PartID:   1002
Qty:      1

Result:
anonymous block completed
Adding new order for customer 1.
This order encountered the following error: 
ORA-01403: no data found                        

--Test condition:  Invalid Part ID:

CustID:   1
OrderID:  6099
PartID:   0
Qty:      1

Result:
anonymous block completed
Adding new order for customer 1.
This order encountered the following error: 
ORA-01403: no data found                           

--Test condition:  Invalid quantity:

CustID:   1
OrderID:  6099
PartID:   1002
Qty:      0

Result:
anonymous block completed
OTHERS ERROR                                                                                                                                                                                                                     
User-Defined Exception        

--Test condition:  NULL CustID:

CustID:   NULL
OrderID:  6099
PartID:   1002
Qty:      1

Result:
Error report -
ORA-06550: line 4, column 46:
PLS-00103: Encountered the symbol ";" when expecting one of the following:

   ( - + case mod new not null <an identifier>
   <a double-quoted delimited-identifier> <a bind variable>
   continue avg count current exists max min prior sql stddev
   sum variance execute forall merge time timestamp interval
   date <a string literal with character set specification>
   <a number> <a single-quoted SQL string> pipe
   <an alternatively-quoted string literal with character set specification>
   <an alternatively
ORA-06550: line 68, column 29:
PLS-00103: Encountered the symbol "JOIN" when expecting one of the following:

   , ; for group having intersect minus order start union where
   connect
06550. 00000 -  "line %s, column %s:\n%s"
*Cause:    Usually a PL/SQL compilation error.
*Action:

--Test condition:



--Test condition:



--Test condition:
