/*
Marc Kelleher
CIS 276
Lab 6
2/20/18
*/

SET SERVEROUTPUT ON FORMAT WRAPPED
    
DECLARE --Declare outer code block.
    
    --Accept user data input:
    inCustID      CUSTOMERS.CustID%TYPE   := &Customer_ID;
    inOrderID     ORDERS.OrderID%TYPE     := &Order_ID;
    inPartID      INVENTORY.PartID%TYPE   := &Part_ID;
    inQty         ORDERITEMS.Qty%TYPE     := &Quantity;
    v_Test         VARCHAR2(512);
    v_Counter      NUMBER := 0;
    v_NewOrder     ORDERS.OrderID%TYPE;
    v_EmpID        ORDERS.EmpID%TYPE; 
    v_CustID       CUSTOMERS.CustID%TYPE;
    v_SYSDATE      ORDERS.SalesDate%TYPE;
    v_NewQty       INVENTORY.StockQty%TYPE;
    v_Flag         CHAR(1) := 'N';
    v_NoCustMsg    VARCHAR2(512);
    v_NoOrder      VARCHAR2(512);
    v_HasOrder     VARCHAR2(512);
    v_PartExist    VARCHAR2(512);
    v_QtyAboveZero VARCHAR2(512);
    v_OutOfStock   VARCHAR2(512);   
    Customer_Not_Exist  EXCEPTION;
    OrderID_Not_Exist   EXCEPTION;
    Order_Not_Belong    EXCEPTION;
    Part_Not_Exist      EXCEPTION;
    Qty_Not_Grtr_Zero   EXCEPTION;
    Out_OF_Stock        EXCEPTION;
    --PRAGMA EXCEPTION_INIT(Error, -00001);
    v_ErrorMessage CHAR(225) := 'Error Message';
    
  
BEGIN --Begin outer code block
    
    BEGIN --Begin verify cust
        
        --Verify the customer exists:
        v_Test := 'Customer_Not_Exist';
        SELECT  COUNT(C.CustID)
        INTO    v_Counter
        FROM    CUSTOMERS C
        WHERE   C.CustID = inCustID;
        
    EXCEPTION --Exception verify cust
    
      WHEN NO_DATA_FOUND THEN
        RAISE Customer_Not_Exist;
        
    END; --End verify cust
    
    BEGIN --Begin verify order
        
        --Verify OrderID exists:
        v_Test := 'OrderID_Not_Exist';
        SELECT  COUNT(O.OrderID)
        INTO    v_Counter
        FROM    Orders O
        WHERE   O.OrderID = inOrderID;
        
    EXCEPTION --Exception verify order
    
      WHEN NO_DATA_FOUND THEN
        RAISE OrderID_Not_Exist;
        
    END; --End verify order 
        
    BEGIN --Begin verify order belong
    
        --Verify the order belongs to the customer:
        v_Test := 'Order_Not_Belong';
        SELECT  COUNT(C.CustID)
        INTO    v_Counter
        FROM    CUSTOMERS C JOIN ORDERS O ON C.CustID = O.CustID
        WHERE   C.CustID = inCustID AND O.OrderID = inOrderID;
    
    EXCEPTION --Exception order belong
    
      WHEN NO_DATA_FOUND THEN
        RAISE Order_Not_Belong;
        
    END; --End order belong
        
    BEGIN --Begin verify part exists
        
        --Verify the part exists:
        v_Test := 'Part_Not_Exist';
        SELECT  COUNT(OI.PartID)
        INTO    v_Counter
        FROM    ORDERITEMS OI
        WHERE   OI.PartID = inPartID;
        
    EXCEPTION --Exception part exists
    
      WHEN NO_DATA_FOUND THEN
        RAISE Part_Not_Exist;
        
    END; --End part exists
    
    BEGIN --Begin verify qty. 
    
        --Verify the quantity entered is more than zero:
        v_Test := 'Qty_Not_Grtr_Zero';   
        IF      inQty <= 0 THEN
        RAISE Qty_Not_Grtr_Zero;
        END IF;
        
    EXCEPTION --Exception verify qty.
    
      WHEN NO_DATA_FOUND THEN
        RAISE Qty_Not_Grtr_Zero;
        
    END; --End verify qty.
    
    BEGIN --Begin update order
      
      DBMS_OUTPUT.PUT_LINE('Adding new order for customer ' || inCustID || '.');
      --Create new order ID:
      SELECT  NVL((MAX(OrderID)+1), 1)
      INTO    v_NewOrder
      FROM    ORDERS;
      
      SELECT  O.EmpID
      INTO    v_EmpID
      FROM    CUSTOMERS C JOIN ORDERS O ON C.CustID = O.CustID
      WHERE   C.CustID = inCustID AND O.OrderID = inOrderID;
      --FROM    ORDERS O, CUSTOMERS C
      --WHERE   C.CustID = C.CustID AND 
    
      --Insert new values into ORDERITEMS:
      INSERT INTO ORDERS  
          (OrderID, EmpID, CustID, SalesDate)
      VALUES 
          (v_NewOrder, v_EmpID, inCustID, SYSDATE);
      
      --Update stock qty after order:
      UPDATE  INVENTORY
      SET     StockQty = (StockQty - inQty)
      WHERE   PartID = inPartID;
      
      --Verify the new StockQty is < 0:
      SELECT  INVENTORY.StockQty
      INTO    v_NewQty
      FROM    INVENTORY
      WHERE   PartID = inPartID;
      
      IF v_NewQty < 0 THEN
        RAISE Out_Of_Stock;  
        
      END IF;  
      
      COMMIT;
      DBMS_OUTPUT.PUT_LINE('You order is successful!'); 
      
    EXCEPTION --Exception update order
    
      --For data not validated.
      WHEN OTHERS THEN
      v_ErrorMessage := SQLERRM;
      DBMS_OUTPUT.PUT_LINE  ('This order encountered the following error: '); 
      DBMS_OUTPUT.PUT_LINE (v_ErrorMessage);
      
      --Rollback the changes:
      ROLLBACK;
    
    END; --End update order
      
EXCEPTION --Exception outer code block.

    --Raised exceptions:
    WHEN NO_DATA_FOUND THEN
        IF v_Test = 'Customer_Not_Exist' THEN
          v_NoCustMsg := 'Customer #' || inCustID || ' does not exist.';
          DBMS_OUTPUT.PUT_LINE(v_NoCustMsg);
        END IF;
        
        IF v_Test = 'OrderID_Not_Exist' THEN
          v_NoOrder      := 'Order #' || inOrderID || ' does not exist.';
          DBMS_OUTPUT.PUT_LINE(v_NoOrder);
        END IF;
        
        IF v_Test = 'Order_Not_Belong' THEN
          v_HasOrder     := 'Order #' || inOrderID || ' does not belong to this customer.';
          DBMS_OUTPUT.PUT_LINE(v_HasOrder);
        END IF;
        
        IF v_Test = 'Part_Not_Exist' THEN
          v_PartExist    := 'Part #' || inPartID || ' does not exist. ';
          DBMS_OUTPUT.PUT_LINE(v_PartExist);
        END IF;
        
        IF v_Test = 'Qty_Not_Grtr_Zero' THEN
          v_QtyAboveZero := 'Quantity needs to be more than zero.';
          DBMS_OUTPUT.PUT_LINE(v_QtyAboveZero);
        END IF;
        
    WHEN Out_Of_Stock THEN
        v_OutOfStock   := 'Part #' || inPartID || ' is out of stock.';
        DBMS_OUTPUT.PUT_LINE(v_OutOfStock);

    WHEN OTHERS THEN
        v_ErrorMessage := 'OTHERS ERROR';
        DBMS_OUTPUT.PUT_LINE(v_ErrorMessage);
        
        v_ErrorMessage := SQLERRM;         
        DBMS_OUTPUT.PUT_LINE(v_ErrorMessage);
    
END; --End outer code block.    
/
 
--SQL> @cursorforloop1